package com.lezar.store

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 17, 22)
    private val panel = Color.rgb(29, 30, 39)
    private val red = Color.rgb(255, 57, 79)
    private val white = Color.WHITE
    private val muted = Color.rgb(177, 180, 194)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("lezar_store", Context.MODE_PRIVATE) }

    data class Device(val brand: String, val name: String, val code: String)

    private val devices = listOf(
        Device("Xiaomi", "Redmi Note 14", "24094RAD4G"),
        Device("Xiaomi", "Redmi Note 13", "2312DRAABG"),
        Device("Xiaomi", "Redmi Note 12", "23021RAAEG"),
        Device("Xiaomi", "Redmi 13C", "23100RN82L"),
        Device("Xiaomi", "Redmi 12", "23053RN02A"),
        Device("POCO", "POCO X6 Pro", "2311DRK48G"),
        Device("POCO", "POCO M6 Pro", "2312FPCA6G"),
        Device("Samsung", "Galaxy A15", "SM-A155"),
        Device("Samsung", "Galaxy A25", "SM-A256"),
        Device("Samsung", "Galaxy A35", "SM-A356"),
        Device("Samsung", "Galaxy A55", "SM-A556"),
        Device("Samsung", "Galaxy S24", "SM-S921"),
        Device("Samsung", "Galaxy S23 FE", "SM-S711"),
        Device("Huawei", "Nova 11", "FOA-LX9"),
        Device("Huawei", "Nova Y91", "STG-LX1"),
        Device("Huawei", "P60 Pro", "MNA-LX9"),
        Device("HONOR", "HONOR X9b", "ALI-NX1"),
        Device("HONOR", "HONOR X8b", "LLY-NX1"),
        Device("HONOR", "HONOR 90 Lite", "CRT-NX1"),
        Device("OPPO", "OPPO A78", "CPH2565"),
        Device("OPPO", "OPPO A58", "CPH2577"),
        Device("OPPO", "Reno 11 F", "CPH2603"),
        Device("vivo", "vivo Y27", "V2249"),
        Device("vivo", "vivo Y36", "V2247"),
        Device("realme", "realme C55", "RMX3710"),
        Device("realme", "realme 12x", "RMX3998"),
        Device("TECNO", "Spark 20", "KJ5"),
        Device("TECNO", "Spark 20 Pro", "KJ6"),
        Device("TECNO", "Camon 30", "CL6"),
        Device("Infinix", "Hot 40", "X6836"),
        Device("Infinix", "Hot 40 Pro", "X6837"),
        Device("Infinix", "Note 30", "X6833B"),
        Device("Google", "Pixel 7a", "GHL1X"),
        Device("Google", "Pixel 8", "GPJ41"),
        Device("OnePlus", "Nord CE 3 Lite", "CPH2467"),
        Device("Motorola", "Moto G54", "XT2343"),
        Device("Nokia", "G42", "TA-1581"),
        Device("ASUS", "ROG Phone 7", "AI2205")
    )

    private val sensitivityNames = listOf("عام", "النقطة الحمراء", "سكوب 2x", "سكوب 4x", "القناص", "النظرة الحرة")
    private val defaultValues = listOf(180, 170, 160, 150, 90, 120)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun baseScreen(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(14), dp(18), dp(12))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        header.addView(label("LEZAR STORE", 13, red, true))
        header.addView(label(title, 26, white, true).apply { setPadding(0, dp(5), 0, 0) })
        if (subtitle != null) header.addView(label(subtitle, 13, muted, false).apply { setPadding(0, dp(3), 0, dp(8)) })
        root.addView(header)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(16)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        nav.addView(navButton("الرئيسية") { showHome() }, weightedParams())
        nav.addView(navButton("الأجهزة") { showDevices() }, weightedParams())
        nav.addView(navButton("الإحصائيات") { showStats() }, weightedParams())
        root.addView(nav)
        setContentView(root)
    }

    private fun showHome() {
        baseScreen("مرحباً بيك 👋", "رفيقك لإعدادات فري فاير — إصدار 1.0")
        val model = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
        card {
            addView(label("جهازك الحالي", 14, muted, false))
            addView(label(model, 20, white, true).apply { setPadding(0, dp(5), 0, dp(5)) })
            addView(label("معلومات الجهاز تُقرأ من أندرويد. اختار جهازك يدوياً لو الاسم غير دقيق.", 12, muted, false))
            addView(actionButton("اختيار الجهاز والإعدادات") { showDevices() })
        }
        card {
            addView(label("إعدادات الحساسية", 18, white, true))
            addView(label("قيم مقترحة قابلة للتعديل من 0 إلى 200. ما في قيمة واحدة مضمونة لكل اللاعبين.", 13, muted, false).apply { setPadding(0, dp(5), 0, dp(8)) })
            addView(actionButton("فتح الحساسية") { showSensitivity(null) })
        }
        card {
            addView(label("ادخل اللعبة مباشرة", 18, white, true))
            addView(label("اختار النسخة المثبتة عندك وافتحها بضغطة واحدة.", 13, muted, false).apply { setPadding(0, dp(5), 0, dp(8)) })
            addView(actionButton("▶ دخول Free Fire") { launchGame("com.dts.freefireth") })
            addView(actionButton("▶ دخول Free Fire MAX") { launchGame("com.dts.freefiremax") })
        }
        card {
            addView(label("تدريب يومي", 18, white, true))
            addView(label("تدرّب على تتبّع الهدف والتحكم بالسحب داخل ساحة التدريب، وسجّل نتائجك في الإحصائيات.", 13, muted, false))
        }
        card {
            addView(label("تنبيه مهم", 15, red, true))
            addView(label("التطبيق لا يغيّر ملفات اللعبة ولا ينفّذ تصويباً آلياً. الإعدادات اقتراحات فقط، والنتيجة تختلف حسب الجهاز وطريقة اللعب.", 12, muted, false))
        }
    }

    private fun showDevices(query: String = "") {
        baseScreen("اختيار الجهاز", "ابحث باسم الجهاز أو رقم الموديل")
        val search = EditText(this).apply {
            hint = "مثال: Redmi Note 13 أو SM-A155"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(panel, 14)
            setText(query)
        }
        content.addView(search, matchParams())
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        fun refresh(q: String) {
            results.removeAllViews()
            val found = devices.filter { "${it.brand} ${it.name} ${it.code}".contains(q.trim(), true) }
            if (found.isEmpty()) results.addView(label("ما لقينا الجهاز في القائمة. جرّب الاسم بالإنجليزي أو استخدم إعدادات عامة.", 14, muted, false).apply { setPadding(0, dp(14), 0, 0) })
            found.forEach { d ->
                cardInto(results) {
                    addView(label("${d.brand} · ${d.name}", 16, white, true))
                    addView(label("Model: ${d.code}", 12, muted, false).apply { setPadding(0, dp(3), 0, dp(7)) })
                    addView(actionButton("اختيار هذا الجهاز") { prefs.edit().putString("selected_device", "${d.brand} ${d.name} (${d.code})").apply(); showSensitivity("${d.brand} ${d.name}") })
                }
            }
        }
        search.addTextChangedListener(SimpleTextWatcher { refresh(it) })
        refresh(query)
        content.addView(actionButton("إعدادات عامة لأي جهاز") { showSensitivity(null) })
    }

    private fun showSensitivity(deviceName: String?) {
        val selected = deviceName ?: prefs.getString("selected_device", detectedDeviceLabel()) ?: detectedDeviceLabel()
        val deviceKey = selected.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "unknown_device" }
        val profileDefaults = suggestedProfile(selected)
        sensitivitySeekBars.clear()
        baseScreen("الحساسية", selected)
        content.addView(label("هذه اقتراحات مبدئية لهذا الموديل. عدّلها حسب استجابة جهازك واحفظها؛ إعدادات كل جهاز تُحفظ منفصلة.", 13, muted, false).apply { setPadding(0, 0, 0, dp(10)) })
        sensitivityNames.forEachIndexed { index, name ->
            val key = "sensitivity_${deviceKey}_$index"
            val initial = prefs.getInt(key, profileDefaults[index])
            card {
                val line = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                line.addView(label(name, 15, white, true), LinearLayout.LayoutParams(0, -2, 1f))
                val valueLabel = label(initial.toString(), 16, red, true)
                line.addView(valueLabel)
                addView(line)
                val seek = SeekBar(this@MainActivity).apply {
                    max = 200
                    progress = initial
                    progressTintList = android.content.res.ColorStateList.valueOf(red)
                    thumbTintList = android.content.res.ColorStateList.valueOf(red)
                }
                seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { valueLabel.text = progress.toString() }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
                addView(seek)
                addView(label("من 0 إلى 200", 11, muted, false))
                tag = "sensitivity_card_$index"
                setOnClickListener { }
                setPadding(dp(14), dp(12), dp(14), dp(10))
                // Save each slider reference so the Save button can read it.
                sensitivitySeekBars[index] = seek
            }
        }
        content.addView(actionButton("حفظ الإعدادات") {
            sensitivitySeekBars.forEach { (index, seek) -> prefs.edit().putInt("sensitivity_${deviceKey}_$index", seek.progress).apply() }
            prefs.edit().putString("selected_device", selected).apply()
            toast("تم حفظ إعدادات الحساسية على تلفونك")
        })
        content.addView(actionButton("رجوع للأجهزة") { showDevices() })
    }

    private val sensitivitySeekBars = mutableMapOf<Int, SeekBar>()

    private fun showStats() {
        baseScreen("إحصائياتك", "سجّل الأرقام بنفسك بعد اللعب")
        val savedHeads = prefs.getInt("heads", 0)
        val savedShots = prefs.getInt("shots", 0)
        val headsInput = EditText(this).apply {
            hint = "عدد الهيدشوت"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(white); setHintTextColor(muted); textSize = 16f
            setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(panel, 14)
            setText(if (savedHeads == 0) "" else savedHeads.toString())
        }
        val shotsInput = EditText(this).apply {
            hint = "إجمالي الطلقات أو المحاولات"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(white); setHintTextColor(muted); textSize = 16f
            setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(panel, 14)
            setText(if (savedShots == 0) "" else savedShots.toString())
        }
        content.addView(label("الهيدشوت المسجّل", 14, muted, true))
        content.addView(headsInput, matchParams())
        content.addView(space(8))
        content.addView(label("إجمالي الطلقات/المحاولات", 14, muted, true))
        content.addView(shotsInput, matchParams())
        content.addView(space(12))
        val result = label("${accuracy(savedHeads, savedShots)}%", 34, red, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)) }
        card { addView(label("النسبة المسجّلة", 14, muted, false)); addView(result) }
        content.addView(actionButton("حفظ الإحصائيات") {
            val heads = headsInput.text.toString().toIntOrNull() ?: 0
            val shots = shotsInput.text.toString().toIntOrNull() ?: 0
            if (heads < 0 || shots < 0 || heads > shots) {
                toast("تأكد من الأرقام: الهيدشوت ما يكون أكبر من الإجمالي")
            } else {
                prefs.edit().putInt("heads", heads).putInt("shots", shots).putString("last_stats_date", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())).apply()
                result.text = "${accuracy(heads, shots)}%"
                toast("تم حفظ الإحصائيات")
            }
        })
        content.addView(label("ملاحظة: هذه الإحصائيات يدوية وليست قراءة تلقائية من خوادم فري فاير.", 12, muted, false).apply { setPadding(0, dp(10), 0, 0) })
    }

    private fun detectedDeviceLabel(): String = "${Build.MANUFACTURER} ${Build.MODEL}".trim()

    private fun suggestedProfile(device: String): List<Int> {
        val d = device.lowercase(Locale.ROOT)
        // Profiles are starting suggestions by device family, not guaranteed game settings.
        return when {
            d.contains("rog phone") || d.contains("red magic") -> listOf(190, 180, 170, 160, 100, 130)
            d.contains("pixel") || d.contains("s24") || d.contains("s23") -> listOf(175, 165, 155, 145, 85, 115)
            d.contains("redmi") || d.contains("poco") || d.contains("xiaomi") -> listOf(185, 175, 165, 155, 95, 125)
            d.contains("tecno") || d.contains("infinix") -> listOf(190, 180, 170, 160, 100, 130)
            d.contains("huawei") || d.contains("honor") -> listOf(180, 170, 160, 150, 90, 120)
            d.contains("samsung") || d.contains("galaxy") -> listOf(175, 165, 155, 145, 85, 115)
            d.contains("oppo") || d.contains("vivo") || d.contains("realme") -> listOf(185, 175, 165, 155, 95, 125)
            else -> defaultValues
        }
    }

    private fun launchGame(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            try {
                startActivity(intent)
            } catch (_: Exception) {
                toast("تعذّر فتح اللعبة. جرّب فتحها من قائمة التطبيقات.")
            }
        } else {
            val gameName = if (packageName == "com.dts.freefiremax") "Free Fire MAX" else "Free Fire"
            toast("$gameName ما مثبتة على تلفونك.")
        }
    }

    private fun accuracy(heads: Int, shots: Int): Int = if (shots <= 0) 0 else ((heads.toDouble() / shots) * 100).toInt().coerceIn(0, 100)

    private fun card(block: LinearLayout.() -> Unit) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(panel, 18) }
        c.block()
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(12)
        content.addView(c, lp)
    }

    private fun cardInto(parent: LinearLayout, block: LinearLayout.() -> Unit) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(panel, 16) }
        c.block()
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(8)
        parent.addView(c, lp)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 14f; setTextColor(white); isAllCaps = false
        background = rounded(red, 14); setPadding(dp(12), dp(6), dp(12), dp(6))
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10)
        layoutParams = lp
        setOnClickListener { action() }
    }

    private fun navButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 11f; setTextColor(white); isAllCaps = false
        background = rounded(panel, 12); minHeight = dp(42); setPadding(dp(2), 0, dp(2), 0)
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchParams() = LinearLayout.LayoutParams(-1, -2)
    private fun weightedParams() = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private class SimpleTextWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
